const Fingerprint = require('fingerprintjs');
export const fingerprint = new Fingerprint().get();
export default {

};