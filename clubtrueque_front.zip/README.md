This project was bootstrapped with [Create React App Typescript]

Owner: jorgefprietol@gmail.com

Demo: 

## Usage

First `npm i` then:

### `npm start`

Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### `npm run build`

Builds the app for production to the `build` folder.
